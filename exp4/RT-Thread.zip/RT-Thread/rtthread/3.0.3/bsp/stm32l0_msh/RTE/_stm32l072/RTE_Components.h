
/*
 * Auto generated Run-Time-Environment Component Configuration File
 *      *** Do not modify ! ***
 *
 * Project: 'project' 
 * Target:  'stm32l072' 
 */

#ifndef RTE_COMPONENTS_H
#define RTE_COMPONENTS_H


/*
 * Define the Device Header File: 
 */
#define CMSIS_device_header "stm32l0xx.h"

#define RTE_FINSH_USING_MSH
#define RTE_USING_DEVICE

#endif /* RTE_COMPONENTS_H */
