#pragma once
#ifndef POSITION_H
#define POSITION_H

class Position {
private:
	int x;
	int y;

public:
	Position(int x = 0, int y = 0);
	
	bool operator==(const Position& p);

	int getX();
	int getY();

	void setX(int x);
	void setY(int y);
};

#endif