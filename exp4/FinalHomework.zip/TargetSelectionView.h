#pragma once
#ifndef TARGET_SELECTION_VIEW_H
#define TARGET_SELECTION_VIEW_H

#include "MazeView.h"

class TargetSelectionView : public MazeView {
private:
	Position targetPosition;

public:
	TargetSelectionView(Maze* maze, int index, MessageReceiver mainMessageReceiver);

	virtual void onKeyDown(char ch);
	virtual void draw();
};

#endif