
static const int L = 20;

#include<iostream>
#include<windows.h>
#include <conio.h>
#include<stdexcept>

#include<fstream>
#include<string>
#include<vector>

#include<ctime>

#include "Maze.h"
#include "Item.h"
#include "ItemStorage.h"
#include "BombItem.h"
#include "View.h"
#include "StartMenuView.h"
#include "MazeView.h"
#include "ItemStorageView.h"
#include "TargetSelectionView.h"
#include "TPItem.h"
#include "MessageDisplayView.h"
#include "PauseView.h"
#include "DataSavingUtils.h"

using namespace std;

void gotoxy(short x, short y);

void initializeItemStorage(ItemStorage& storage);

Maze* readMazeFromFile();
Maze* generateRandomMaze();

Maze* maze;
ItemStorage* itemStorage;
int selectedItemIndex;

vector<View*> viewList;
View* currentView = NULL;
bool terminated = false;

View* viewBeforeMessage=NULL;

void switchView(View* view);
void terminateProgram();
void displayMessage(const string& msg);

void saveMaze();

void CreateMaze(int** maze, int x1, int y1, int x2, int y2) {
   
    if (x2 - x1 < 2 || y2 - y1 < 2) {
        return;
    }

    
    int x = x1 + 1 + rand() % (x2 - x1 - 1);
    int y = y1 + 1 + rand() % (y2 - y1 - 1);

    
    for (int i = x1; i <= x2; i++) maze[i][y] = ELEMENT_WALL;
    for (int i = y1; i <= y2; i++) maze[x][i] = ELEMENT_WALL;

 
    CreateMaze(maze, x1, y1, x - 1, y - 1);
    CreateMaze(maze, x + 1, y + 1, x2, y2);
    CreateMaze(maze, x + 1, y1, x2, y - 1);
    CreateMaze(maze, x1, y + 1, x - 1, y2);


    int r[4] = { 0 };
    r[rand() % 4] = 1;


    for (int i = 0; i < 4; i++) {
        if (r[i] == 0) {
            int rx = x;
            int ry = y;
            switch (i) {
            case 0:
                
                do {
                    rx = x1 + rand() % (x - x1);
                } while (maze[rx - 1][ry] + maze[rx + 1][ry] + maze[rx][ry - 1] + maze[rx][ry + 1] > 2 * ELEMENT_WALL);
                break;
            case 1:
                do {
                    ry = y + 1 + rand() % (y2 - y);
                } while (maze[rx - 1][ry] + maze[rx + 1][ry] + maze[rx][ry - 1] + maze[rx][ry + 1] > 2 * ELEMENT_WALL);
                break;
            case 2:
                do {
                    rx = x + 1 + rand() % (x2 - x);
                } while (maze[rx - 1][ry] + maze[rx + 1][ry] + maze[rx][ry - 1] + maze[rx][ry + 1] > 2 * ELEMENT_WALL);
                break;
            case 3:
                do {
                    ry = y1 + rand() % (y - y1);
                } while (maze[rx - 1][ry] + maze[rx + 1][ry] + maze[rx][ry - 1] + maze[rx][ry + 1] > 2 * ELEMENT_WALL);
                break;
            default:
                break;
            }
            maze[rx][ry] = ELEMENT_AIR;
        }
    }
}
void produce(int* p) {

    srand((unsigned)time(NULL));

    int** Maze = (int**)malloc(L * sizeof(int*));
    for (int i = 0; i < L; i++) {
        Maze[i] = (int*)calloc(L, sizeof(int));
    }

    
    for (int i = 0; i < L; i++) {
        Maze[0][i] = ELEMENT_WALL;
        Maze[i][0] = ELEMENT_WALL;
        Maze[L - 1][i] = ELEMENT_WALL;
        Maze[i][L - 1] = ELEMENT_WALL;
    }

   
    CreateMaze(Maze, 1, 1, L - 2, L - 2);

    
    Maze[1][0] = ELEMENT_AIR;
    Maze[L - 2][L - 1] = ELEMENT_AIR;

    
    for (int i = 0; i < L; i++) {
        for (int j = 0; j < L; j++) {
           
            *(p + i * L + j) = Maze[i][j];
        }

        
    }
}

void mainMessageReceiver(int sender, int target, int what, void* msg, bool deleteAfterRead) {
    if (target >= 0) {
        //Isn't a message to main receiver
        //Relay to other view

        viewList[target]->onMessageReceived(sender, what, msg, deleteAfterRead);
        return;
    }

    //Message for main
    if (sender == 0) {
        //Message from start menu
        //Only menu selection, in msg pointer

        int menuSelection = *(int*)msg;
        switch (menuSelection) {
        case 0://Continue
        {
            //Load maze
            int time = restoreGameProgress(maze, itemStorage).remaingTime;
            
            ((MazeView*)viewList[1])->setTime(time);

            //Switch to maze view
            switchView(viewList[1]);
        }
            break;
        case 1://New
            //Switch to game view
            switchView(viewList[1]);
            break;
        case 2://Quit
            cout << "��л����" << endl;
            terminateProgram();
            break;
        }
    }
    else if (sender == 1) {
        //Message from maze view
        //what msg meaning
        //1 null match finished
        //2 null to item storage
		//3 null reach treasure
        //4 null time is up
        //5 null pause view

        if (what == 1) {
            cout << "\n��ϲͨ��" << endl;
            terminateProgram();
        }
        else if (what == 2) {
            switchView(viewList[2]);
		}
		else if (what == 3) {
			//Get a random item
			srand(time(0));
			int i = rand() % 3;
			string msg = "";
			switch (i) {
			case 0:
				msg = "���ź�����������ǿյ�";
				break;
			case 1:
				msg = "��ϲ�㣬����һ������ ը��";
				itemStorage->itemList.push_back(new BombItem);
				break;
			case 2:
				msg = "��ϲ�㣬����һ������ ����";
				itemStorage->itemList.push_back(new TPITem);
				break;
			}

			displayMessage(msg);
        }
        else if (what == 4) {
            cout << "ʱ��ľ�����Ϸ����" << endl;
            terminateProgram();
        }
        else if (what == 5) {
            switchView(viewList[5]);
        }

    }
    else if (sender == 2) {
        //Message from item storage view
        //what|msg|meaning
        //1| item index pointer| select item
        //2| null| no item selected

        
        if (what == 2) {
            switchView(viewList[1]);
        }
        else if (what == 1) {
            selectedItemIndex = *(int*)msg;
            switchView(viewList[3]);
        }
    }
    else if (sender == 3) {
        //Message from target selection view
        //what|msg|meaning
        //1|NULL|not selected
        //2|selected position|target selected

        if (what == 1) {
            //Return to normal game
            switchView(viewList[1]);
        }
        else if (what == 2) {
            Position targetPos = *(Position*)msg;
            //Use item
            
            Item* item = itemStorage->itemList[selectedItemIndex];
			string errorMsg;
			if (item->action(maze, targetPos,&errorMsg)) {
				itemStorage->itemList[selectedItemIndex]->markUsed();
				//Return to normal game
				switchView(viewList[1]);
			}
			else {
				displayMessage("����ʹ��ʧ�ܣ�ԭ��"+errorMsg);
				
				//Change view that will be chosen later into normal game view
				viewBeforeMessage = viewList[1];
			}
        }
	}
	else if (sender == 4) {
		//Message from message display view
		//what|msg|meaning
		//1|NULL|esc clicked

		if (what == 1) {
			switchView(viewBeforeMessage);
			delete viewList[4];//Release msg view
		}
    }
    else if (sender == 5) {
        //Message from pause view
        //what|msg|meaning
        //0 | choice | chosen
        if (what == 0) {
            int menuSelection = *(int*)msg;
            switch (menuSelection) {
            case 0://Continue
                switchView(viewList[1]);
                break;
            case 1://Save
                saveMaze();
                displayMessage("����ɹ�");
                viewBeforeMessage = viewList[1];
                break;
            case 2://Save and Quit
                saveMaze();
                system("cls");
                cout << "����ɹ�����л����" << endl;
                terminateProgram();
                break;
            case 3://Quit
                system("cls");
                cout << "��л����" << endl;
                terminateProgram();
                break;
            }
        }
    }

    if (deleteAfterRead) {
        delete msg;
    }
}

int main() {
    HANDLE handle = GetStdHandle(STD_OUTPUT_HANDLE);
    CONSOLE_CURSOR_INFO CursorInfo;
    GetConsoleCursorInfo(handle, &CursorInfo);//��ȡ����̨�����Ϣ
    CursorInfo.bVisible = false; //���ؿ���̨���
    SetConsoleCursorInfo(handle, &CursorInfo);//���ÿ���̨���״̬

    //Init game
    maze = generateRandomMaze();
    //maze = readMazeFromFile();
    itemStorage = new ItemStorage;
    initializeItemStorage(*itemStorage);

    //Init views
    viewList.push_back(new StartMenuView(0,mainMessageReceiver));
    viewList.push_back(new MazeView(maze, 1, mainMessageReceiver,true));
    viewList.push_back(new ItemStorageView(itemStorage, 2, mainMessageReceiver));
    viewList.push_back(new TargetSelectionView(maze, 3, mainMessageReceiver));
	viewList.push_back(NULL);
    viewList.push_back(new PauseView(5, mainMessageReceiver));

    switchView(viewList[0]);

    //Start listen for key down event
    while (!terminated) {
        if (_kbhit()) {
            int ch = _getch();
            currentView->onKeyDown(ch);
        }
    }
}

void saveMaze() {
    GameProgress gameProgress;
    gameProgress.maze = maze;
    gameProgress.itemStorage = itemStorage;
    gameProgress.remaingTime = ((MazeView*)viewList[1])->getTime();

    saveGameProgress(gameProgress);
}

void displayMessage(const string& msg) {
	viewBeforeMessage = currentView;
	MessageDisplayView* msgView = new MessageDisplayView(4, mainMessageReceiver, msg);
	viewList[4]=msgView;

	switchView(msgView);
}

void switchView(View* view) {
    if (currentView != NULL)
        currentView->setFocusStatus(false);
    view->setFocusStatus(true);

    currentView = view;
    system("cls");
    gotoxy(0, 0);
    view->draw();
}

void terminateProgram() {
    terminated = true;
}

void initializeItemStorage(ItemStorage& storage) {
    vector<Item*> itemList;
    for (int i = 0; i < 6; i++) {
        itemList.push_back(new BombItem);
    }

	for (int i = 0; i < 6; i++) {
		itemList.push_back(new TPITem);
	}

    storage.itemList = itemList;
    storage.currentSelectedItemIndex = 0;
}

Maze* generateRandomMaze() {
    Maze* maze = new Maze;

    maze->setMousePosition(Position(1, 1));
    maze->setBarnPosition(Position(L - 1, L - 2));

    Map map(L,L);

    int* arr = new int[L*L];
    produce(arr);

    for (int x = 0; x < L; x++) {
        for (int y = 0; y < L; y++) {
            map.setElemetAt(Position(x, y), arr[y * L + x]);
        }
    }

    srand(time(0));
    for (int i = 0; i < 10; i++) {
        int x = rand() % L;
        int y = rand() % L;

        if (map.getElementAt(Position(x, y)) == ELEMENT_AIR) {
            map.setElemetAt(Position(x, y), ELEMENT_TREASURE);
        }
        else {
            
        }
    }

    delete[] arr;

    maze->setMap(map);

    return maze;
}

Maze* readMazeFromFile() {
    Maze* maze = new Maze;

    fstream mazeFile = fstream("maze.txt", ios::in);

    if (!mazeFile) {
        throw runtime_error("Can not open");
    }

    int xLength = 6;
    int yLength = 6;

    Map map(xLength, yLength);
    char c;
    for (int y = 0; y < yLength; y++) {
        for (int x = 0; x < xLength; x++) {
            c = mazeFile.get();
            switch (c) {
            case AIR_CHAR[0]:
                map.setElemetAt(Position(x, y), ELEMENT_AIR);
                break;
            case WALL_CHAR[0]:
                map.setElemetAt(Position(x, y), ELEMENT_WALL);
                break;
			case MOUSE_CHAR[0]:
				maze->setMousePosition(Position(x, y));
				break;
			case BARN_CHAR[0]:
				maze->setBarnPosition(Position(x, y));
				break;
			case TREASURE_CHAR[0]:
				map.setElemetAt(Position(x, y), ELEMENT_TREASURE);
				break;
            }
        }
        mazeFile.get();
    }

    maze->setMap(map);
    return maze;
}

void gotoxy(short x, short y) {
	COORD coord = { x, y };
	SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
}