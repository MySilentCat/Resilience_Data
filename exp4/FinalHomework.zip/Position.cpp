#include"Position.h"

Position::Position(int x, int y) {
	this->x = x;
	this->y = y;
}

bool Position::operator==(const Position& p) {
	return x == p.x && y == p.y;
}

int Position::getX() {
	return x;
}
int Position::getY() {
	return y;
}

void Position::setX(int xx) {
	x = xx;
}
void Position::setY(int yy) {
	y = yy;
}