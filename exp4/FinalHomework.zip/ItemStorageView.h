#pragma once
#ifndef ITEM_STORAGE_VIEW_H
#define ITEM_STORAGE_VIEW_H

#include "View.h"
#include "ItemStorage.h"

class ItemStorageView : public View {
private:
	ItemStorage* itemStorage;
public:
	ItemStorageView(ItemStorage* itemStorage, int index, MessageReceiver mainMessageReceiver);

	virtual void draw();
	virtual void onKeyDown(char ch);
};

#endif
