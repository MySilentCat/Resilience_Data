#include "MazeView.h"
#include<windows.h>
#include<iostream>
#include<iomanip>

using namespace std;

void MazeView::gotoxy(short x, short y) {
	View::gotoxy(x, y);
}

void timing(bool* end,MazeView* mazeView) {
	while (!(*end)) {
		Sleep(1000);
		mazeView->tick();
	}
}

void MazeView::tick() {
	if (focused) {
		timeRemaining--;
		updateUI(true);
		//drawTime();
		if (timeRemaining <= 0) {
			//Time is up, send message to terminate game
			mainMessageReceiver(index, -1, 4, NULL, false);
		}
	}
	
}

MazeView::MazeView(Maze* maze, int index, MessageReceiver mainMessageReceiver,bool showTimer,int time):
View(index,mainMessageReceiver),maze(maze),timeRemaining(time), showTimer(showTimer){
	if (showTimer) {
		timingThread = thread(timing, &this->endTick, this);
	}
}

void MazeView::onKeyDown(char ch) {
	
	int moveDirection = DIRECION_X;
	int step = 0;
	switch (ch) {
	case KEY_UP://UP
		moveDirection = DIRECION_Y;
		step = -1;
		break;
	case KEY_DOWN://DOWN
		moveDirection = DIRECION_Y;
		step = 1;
		break;
	case KEY_LEFT://LEFT
		moveDirection = DIRECION_X;
		step = -1;
		break;
	case KEY_RIGHT://RIGHT
		moveDirection = DIRECION_X;
		step = 1;
		break;
	case 'b':
		//Change to item storage
		mainMessageReceiver(index, -1, 2, NULL, false);
		return;
	case KEY_ESC:
		//Pause view
		mainMessageReceiver(index, -1, 5, NULL, false);
		return;
	}

	if (maze->move(Move(moveDirection, step))) {
		//Move success, need to redraw
		updateUI(false);

		if (maze->getMousePosition() == maze->getBarnPosition()) {
			//Reach barn
			//Send message
			mainMessageReceiver(index, -1, 1, NULL, false);
		}

		int currentElement = maze->getMap().getElementAt(maze->getMousePosition());
		//Check if reach barn
		
		if (currentElement == ELEMENT_TREASURE) {
			//Reach treasure
			//Send message
			mainMessageReceiver(index, -1, 3, NULL, false);

			//Claer the treasure
			maze->getEditableMap().setElemetAt(maze->getMousePosition(), ELEMENT_AIR);
		}
	}
}

void MazeView::setTime(int time) {
	timeRemaining = time;
}

int MazeView::getTime() {
	return timeRemaining;
}

void MazeView::draw() {
	drawMaze(maze);
	if(showTimer)
		drawTime();
}

void MazeView::updateUI(bool onlyTime) {
	while (threadSafetyLocked) {
		//Wait
	}
	threadSafetyLocked = true;

	if (!onlyTime) {
		drawMaze(maze);
	}

	if (showTimer) {
		drawTime();
	}

	threadSafetyLocked = false;
}

void MazeView::drawTime(){
	gotoxy(0, maze->getMap().getYLength());
	cout << "ʣ��ʱ�䣺" <<left<<setw(4)<< timeRemaining<<"s\n";
}

void MazeView::drawMaze(Maze* maze) {
	gotoxy(0, 0);

	const Map& map = maze->getMap();

	int xLength = map.getXLength();
	int yLength = map.getYLength();

	Position mousePositon = maze->getMousePosition();
	Position barnPosition = maze->getBarnPosition();

	for (int y = 0; y < yLength; y++) {
		for (int x = 0; x < xLength; x++) {

			Position currentPos = Position(x, y);
			if (currentPos == mousePositon) {
				cout << MOUSE_CHAR << " ";
				continue;
			}
			else if (currentPos == barnPosition) {
				cout << BARN_CHAR << " ";
				continue;
			}

			switch (map.getElementAt(currentPos)) {
			case ELEMENT_AIR:
				cout << AIR_CHAR;
				break;
			case ELEMENT_WALL:
				cout << WALL_CHAR;
				break;
			case ELEMENT_MOUSE:
				cout << MOUSE_CHAR;
				break;
			case ELEMENT_BARN:
				cout << BARN_CHAR;
				break;
			case ELEMENT_TREASURE:
				cout << TREASURE_CHAR;
				break;
			}

			cout << " ";
		}
		cout << "\n";
	}
}