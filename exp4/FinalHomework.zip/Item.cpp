#include "Item.h"

string Item::getName() const {
	return itemName;
}

void Item::setName(const string& name) {
	this->itemName = name;
}

Item::Item(const string& itemName) {
	this->itemName = itemName;
}

void Item::markUsed() {
	used = true;
}

bool Item::isUsed() const {
	return used;
}