#include"Map.h"

int Map::getElementAt(Position position)const {
	return mapArray[position.getY()*xLength + position.getX()];
}
Map::Map(int xLength, int yLength) {
	this->xLength = xLength;
	this->yLength = yLength;
	mapArray = new int[xLength*yLength];

	for (int i = 0; i < xLength*yLength; i++) {
		mapArray[i] = 0;
	}
}

Map::Map(const Map& map) {
	this->xLength = map.xLength;
	this->yLength = map.yLength;
	mapArray = new int[xLength*yLength];

	for (int i = 0; i < xLength*yLength; i++) {
		mapArray[i] = map.mapArray[i];
	}
}

void Map::operator=(const Map& map) {
	this->xLength = map.xLength;
	this->yLength = map.yLength;
	mapArray = new int[xLength*yLength];

	for (int i = 0; i < xLength*yLength; i++) {
		mapArray[i] = map.mapArray[i];
	}
}

Map::~Map() {
	delete[] mapArray;
}

int Map::getXLength() const {
	return xLength;
}
void Map::setXLength(int xLength) {
	this->xLength = xLength;
}

int Map::getYLength() const {
	return yLength;
}
void Map::setYLength(int yLength) {
	this->yLength = yLength;
}

void Map::setElemetAt(Position position, int element) {
	mapArray[position.getY()*xLength + position.getX()] = element;
}