#pragma once
#ifndef BOMB_ITEM_H
#define BOMB_ITEM_H

#include "Item.h"

class BombItem : public Item {
public:
	BombItem();

	virtual bool action(Maze* maze, Position target, string* errorMessage);
};

#endif
