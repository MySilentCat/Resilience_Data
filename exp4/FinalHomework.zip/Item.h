#pragma once
#ifndef ITEM_H
#define ITEM_H

#include"Maze.h"

#include<string>
using namespace std;

class Item {
private:
	string itemName;
	bool used=false;

public:
	//If action failed, return false, no item consumption
	virtual bool action(Maze* maze,Position target,string* errorMessage)=0;

	Item(const string& itemName);

	string getName() const;
	void setName(const string& name);

	void markUsed();
	bool isUsed() const;

};

#endif