#pragma once
#ifndef START_MENU_VIEW_H
#define START_MENU_VIEW_H

#define MENU_WIDTH 80
#define MENU_HEIGHT 20

#include "View.h"

class StartMenuView : public View {
private:
	int currentChoice;

public:
	StartMenuView(int index,MessageReceiver mainMessageReceiver);

	virtual void onKeyDown(char ch);
	virtual void draw();

	void printMenuScreen(int totalWidth, int totalHeight);

};

#endif