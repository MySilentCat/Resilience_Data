#include "TPItem.h"
#include<cmath>

TPITem::TPITem():Item("����") {

}

bool TPITem::action(Maze* maze, Position target, string* errorMessage) {
	//Distance check
	Position mouse = maze->getMousePosition();
	if (abs(target.getX() - mouse.getX()) > 2 || abs(target.getY() - mouse.getY()) > 2) {
		if (errorMessage != NULL)
			*errorMessage = "�����ƶ�����4x4�ķ�Χ";
		return false;
	}

	//Boundary check
	if (target.getX() < 0 || target.getX() >= maze->getMap().getXLength() ||
		target.getY() < 0 || target.getY() >= maze->getMap().getYLength()) {
		//Out of bound
		if (errorMessage != NULL)
			*errorMessage = "��ѡĿ�곬����ͼ�߽�";
		return false;
	}

	//Check target block
	int targetElement = maze->getMap().getElementAt(target);
	if (targetElement != ELEMENT_AIR) {
		if (errorMessage != NULL)
			*errorMessage = "��ѡĿ�겻�ǿ���";
		return false;
	}

	maze->setMousePosition(target);

	return true;
}