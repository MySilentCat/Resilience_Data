#include "View.h"

#include<windows.h>

using namespace std;

void View::gotoxy(short x, short y) {
	COORD coord = { x, y };
	SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
}

View::~View() {

}

View::View(int index, MessageReceiver mainMessageReceiver) {
	this->index = index;
	this->mainMessageReceiver = mainMessageReceiver;
}

void View::setFocusStatus(bool isFocused) {
	focused = isFocused;
}