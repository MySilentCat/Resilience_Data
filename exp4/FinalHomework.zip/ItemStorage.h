#pragma once
#ifndef ITEM_STORAGE_H
#define ITEM_STORAGE_H

#include<vector>
#include "Item.h"

using namespace std;

class ItemStorage {
public:
	vector <Item*> itemList;
	int currentSelectedItemIndex;
};

#endif