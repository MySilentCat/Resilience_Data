#include "BombItem.h"

BombItem::BombItem() :Item("ը��") {

}

bool BombItem::action(Maze* maze, Position target, string* errorMessage) {
	//Boundary check
	if (target.getX() < 0 || target.getX() >= maze->getMap().getXLength() || 
		target.getY() < 0 || target.getY() >= maze->getMap().getYLength()) {
		//Out of bound
		if (errorMessage != NULL)
			*errorMessage = "��ѡĿ�곬����ͼ�߽�";
		return false;
	}

	//Check target block
	int targetElement = maze->getMap().getElementAt(target);
	if (targetElement != ELEMENT_WALL) {
		if (errorMessage != NULL)
			*errorMessage = "��ѡĿ�겻��Χǽ";
		return false;
	}

	maze->getEditableMap().setElemetAt(target, ELEMENT_AIR);

	return true;
}