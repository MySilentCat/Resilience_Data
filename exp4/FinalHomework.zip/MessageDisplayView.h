#pragma once
#ifndef MESSAGE_DISPLAY_VIEW_H
#define MESSAGE_DISPLAY_VIEW_H
#include <string>
#include "View.h"

using namespace std;

class MessageDisplayView : public View {
private:
	string message;

public:
	MessageDisplayView(int index, MessageReceiver mainMessageReceiver,const string& msg);

	virtual void draw();

	virtual void onKeyDown(char ch);
};

#endif
