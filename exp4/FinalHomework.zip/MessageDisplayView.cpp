#include "MessageDisplayView.h"

#include <iostream>

using namespace std;

MessageDisplayView::MessageDisplayView(int index, MessageReceiver mainMessageReceiver, const string& msg):
View(index,mainMessageReceiver),message(msg){

}

void MessageDisplayView::draw() {
	cout << message << endl << "��esc����......";
}

void MessageDisplayView::onKeyDown(char ch) {
	if (ch == KEY_ESC) {
		//ESC key down
		//Send message
		mainMessageReceiver(index, -1, 1, NULL, false);
	}
}