#pragma once
#ifndef GAME_PROGRESS_H
#define GAME_PROGRESS_H

#include "Maze.h"
#include "ItemStorage.h"

class GameProgress {
public:
	Maze* maze;
	ItemStorage* itemStorage;
	int remaingTime;
};

#endif
