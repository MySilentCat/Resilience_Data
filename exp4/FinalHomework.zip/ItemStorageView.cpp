#include "ItemStorageView.h"
#include<iostream>
#include<iomanip>

using namespace std;

ItemStorageView::ItemStorageView(ItemStorage* itemStorage, int index, MessageReceiver mainMessageReceiver):
View(index,mainMessageReceiver),itemStorage(itemStorage){

}

void ItemStorageView::draw() {
    gotoxy(0, 0);

    cout << "���߱�������enterѡ�񣬰�esc�˳�����\n";
    //5 items in one line
    for (int i = 0; i < itemStorage->itemList.size(); i++) {
        if (i % 5 == 0)
            cout << "\n";

        Item* item=itemStorage->itemList[i];

        cout << "(" << ((itemStorage->currentSelectedItemIndex == i) ? "*" : " ") << ")";
		cout << "" << item->getName() << left << setw(15) << (item->isUsed() ? "(��ʹ��)" : "");
    }
}

void ItemStorageView::onKeyDown(char ch) {
    int newSelection = itemStorage->currentSelectedItemIndex;
    switch (ch) {
    case KEY_ESC:
        //No select
        mainMessageReceiver(index, -1, 2, NULL, false);
        return;
    case KEY_ENTER:
        if (itemStorage->itemList[itemStorage->currentSelectedItemIndex]->isUsed())
            return;//Can not select used item

        mainMessageReceiver(index, -1, 1, &itemStorage->currentSelectedItemIndex, false);
        return;
    case KEY_UP:
        newSelection -= 5;
        break;
    case KEY_DOWN:
        newSelection += 5;
        break;
    case KEY_LEFT:
        newSelection -= 1;
        break;
    case KEY_RIGHT:
        newSelection += 1;
        break;
    }

    if (newSelection < 0 || newSelection >= itemStorage->itemList.size()) {
        newSelection = itemStorage->currentSelectedItemIndex;
    }
    itemStorage->currentSelectedItemIndex = newSelection;

    draw();
}