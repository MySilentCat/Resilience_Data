#pragma once
#ifndef PAUSE_VIEW_H
#define PAUSE_VIEW_H

#include "View.h"

class PauseView : public View {
private:
	int currentSelection;

public:
	PauseView(int index, MessageReceiver mainMessageReceiver);

	virtual void draw();
	virtual void onKeyDown(char ch);
};

#endif