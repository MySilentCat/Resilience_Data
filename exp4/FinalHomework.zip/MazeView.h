#pragma once
#ifndef MAZE_VIEW_H
#define MAZE_VIEW_H

#define AIR_CHAR " "
#define WALL_CHAR "*"
#define MOUSE_CHAR "#"
#define BARN_CHAR "B"
#define TREASURE_CHAR "T"

#include "View.h"
#include "Maze.h"

#include <thread>

using namespace std;

class MazeView : public View {
protected:
	Maze* maze;
	int timeRemaining;
	thread timingThread;
	bool endTick = false;
	bool showTimer = true;

	bool threadSafetyLocked = false;

public:
	MazeView(Maze* maze, int index, MessageReceiver mainMessageReceiver,bool showTimer,int time=300);

	virtual void onKeyDown(char ch);
	virtual void draw();

	void drawMaze(Maze* maze);

	void tick();

	void drawTime();

	int getTime();

	void setTime(int time);

	void gotoxy(short x, short y);

	void updateUI(bool onlyTime);
};

#endif