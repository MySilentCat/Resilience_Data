#pragma once
#ifndef VIEW_H
#define VIEW_H

#define KEY_UP 72
#define KEY_DOWN 80
#define KEY_LEFT 75
#define KEY_RIGHT 77
#define KEY_ENTER 13
#define KEY_ESC 27

typedef void (*MessageReceiver)(int sender, int target, int what, void* msg, bool releaseAfterRead);

class View {
protected:
	MessageReceiver mainMessageReceiver;
	int index;
	bool focused;
public:

	View(int index,MessageReceiver mainMessageReceiver);

	virtual void draw() {}
	virtual void onKeyDown(char ch) {}
	
	virtual void onMessageReceived(int sender, int what, void* msg, bool releaseAfterRead) {}

	void gotoxy(short x, short y);

	virtual ~View();

	void setFocusStatus(bool isFocused);
};

#endif