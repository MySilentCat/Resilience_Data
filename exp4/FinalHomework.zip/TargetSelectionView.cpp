#include"TargetSelectionView.h"
#include <iostream>

using namespace std;

void TargetSelectionView::onKeyDown(char ch) {
	Position backup = targetPosition;
	switch (ch) {
	case KEY_ENTER:
		//Selected
		//Send message
		mainMessageReceiver(index, -1, 2, &targetPosition, false);
		return;
	case KEY_ESC:
		//Not selected
		//Send message
		mainMessageReceiver(index, -1, 1, NULL, false);
		return;
	case KEY_UP://UP
		targetPosition.setY(targetPosition.getY() - 1);
		break;
	case KEY_DOWN://DOWN
		targetPosition.setY(targetPosition.getY() + 1);
		break;
	case KEY_LEFT://LEFT
		targetPosition.setX(targetPosition.getX() - 1);
		break;
	case KEY_RIGHT://RIGHT
		targetPosition.setX(targetPosition.getX() + 1);
		break;
	}

	//Boundary checking
	if (targetPosition.getX() < 0 || targetPosition.getX() >= maze->getMap().getXLength()) {
		//Out of map
		targetPosition = backup;
		return;
	}
	if (targetPosition.getY() < 0 || targetPosition.getY() >= maze->getMap().getYLength()) {
		//Out of map
		targetPosition = backup;
		return;
	}

	draw();
}

void TargetSelectionView::draw() {
	MazeView::draw();

	gotoxy((2*targetPosition.getX()), targetPosition.getY());
	printf("%c%c", 161, 246);
}

TargetSelectionView::TargetSelectionView(Maze* maze, int index, MessageReceiver mainMessageReceiver) :
	MazeView(maze,index, mainMessageReceiver,false),targetPosition(Position(0,0)){
	
}