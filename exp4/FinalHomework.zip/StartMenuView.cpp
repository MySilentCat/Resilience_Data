#include "StartMenuView.h"
#include<iostream>

using namespace std;

StartMenuView::StartMenuView(int index,MessageReceiver mainMessageReceiver) 
:View(index,mainMessageReceiver),currentChoice(0){

}

void StartMenuView::onKeyDown(char ch) {
    if (ch == KEY_ENTER) {
        //Enter
        //Send message

        int* choice = new int;
        *choice = currentChoice;

        mainMessageReceiver(index, -1, 0, choice, true);
        return;
    }

    switch (ch) {
    case KEY_UP://UP
        currentChoice--;
        break;
    case KEY_DOWN://DOWN
        currentChoice++;
        break;
    }

    if (currentChoice < 0)
        currentChoice = 2;
    currentChoice %= 3;

    printMenuScreen(MENU_WIDTH, MENU_HEIGHT);
}

void StartMenuView::draw() {
    printMenuScreen(MENU_WIDTH, MENU_HEIGHT);
}

void StartMenuView::printMenuScreen(int totalWidth, int totalHeight) {
    //Border
    gotoxy(0, 0);
    for (int i = 0; i < totalWidth; i++) {
        cout << "*";
    }

    gotoxy(0, totalHeight - 1);
    for (int i = 0; i < totalWidth; i++) {
        cout << "*";
    }

    for (int i = 0; i < totalHeight; i++) {
        gotoxy(totalWidth - 1, i);
        cout << "*";
    }

    //Titie
    gotoxy((totalWidth - 5) / 2 - 5, 2);
    cout << "�������Թ�";

    //Menu
    int menuStartX = totalWidth / 2 - 5;
    gotoxy(menuStartX, 10);
    cout << (currentChoice == 0 ? ">" : " ") << "������Ϸ";
    gotoxy(menuStartX, 11);
    cout << (currentChoice == 1 ? ">" : " ") << "����Ϸ";
    gotoxy(menuStartX, 12);
    cout << (currentChoice == 2 ? ">" : " ") << "�˳�";

    //Return to normal position
    gotoxy(0, totalHeight);
}