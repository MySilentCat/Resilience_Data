#include "PauseView.h"

#include <iostream>

using namespace std;

PauseView::PauseView(int index, MessageReceiver mainMessageReceiver):
View(index,mainMessageReceiver){

}

void PauseView::draw() {
    int totalWidth = 80;
    int totalHeight = 20;

    //Border
    gotoxy(0, 0);
    for (int i = 0; i < totalWidth; i++) {
        cout << "*";
    }

    gotoxy(0, totalHeight - 1);
    for (int i = 0; i < totalWidth; i++) {
        cout << "*";
    }

    for (int i = 0; i < totalHeight; i++) {
        gotoxy(totalWidth - 1, i);
        cout << "*";
    }

    //Titie
    gotoxy((totalWidth - 5) / 2 - 5, 2);
    cout << "��Ϸ��ͣ";

    //Menu
    int menuStartX = totalWidth / 2 - 5;
    gotoxy(menuStartX, 10);
    cout << (currentSelection == 0 ? ">" : " ") << "������Ϸ";
    gotoxy(menuStartX, 11);
    cout << (currentSelection == 1 ? ">" : " ") << "����";
    gotoxy(menuStartX, 12);
    cout << (currentSelection == 2 ? ">" : " ") << "���沢�˳�";
    gotoxy(menuStartX, 13);
    cout << (currentSelection == 3 ? ">" : " ") << "�˳���Ϸ";

    //Return to normal position
    gotoxy(0, totalHeight);
}

void PauseView::onKeyDown(char ch) {
    if (ch == KEY_ENTER) {
        //Enter
        //Send message

        int* choice = new int;
        *choice = currentSelection;

        mainMessageReceiver(index, -1, 0, choice, true);
        return;
    }

    switch (ch) {
    case KEY_UP://UP
        currentSelection--;
        break;
    case KEY_DOWN://DOWN
        currentSelection++;
        break;
    }

    if (currentSelection < 0)
        currentSelection = 3;
    currentSelection %= 4;

    draw();
}