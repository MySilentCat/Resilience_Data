#pragma once

#ifndef DATA_SAVING_UTILS_H
#define DATA_SAVING_UTILS_H

#include<fstream>
#include<vector>

using namespace std;

#include"ItemStorage.h"
#include"Map.h"
#include"Maze.h"
#include "Item.h"
#include "BombItem.h"
#include "TPItem.h"
#include "GameProgress.h"

void saveGameProgress(const GameProgress& gameProgress) {
	fstream file("gameProgress.dat", ios::out);

	//Map x length
	//Map y length
	//Map
	//Mouse Position
	//Barn Position
	//Time
	//ItemName ItemUsed
	//... ...
	const Map& map = gameProgress.maze->getMap();
	file << map.getXLength() << "\n" << map.getYLength() << "\n";
	for (int y = 0; y < map.getYLength(); y++) {
		for (int x = 0; x < map.getXLength(); x++) {
			file << map.getElementAt(Position(x, y)) << " ";
		}
		file << "\n";
	}

	Position mousePosition = gameProgress.maze->getMousePosition();
	file << mousePosition.getX() << " " << mousePosition.getY() << "\n";

	Position barnPosition = gameProgress.maze->getBarnPosition();
	file << barnPosition.getX() << " " << barnPosition.getY() << "\n";

	file << gameProgress.remaingTime << "\n";

	vector<Item*> itemList = gameProgress.itemStorage->itemList;

	for (Item* item : itemList) {
		file << item->getName() << " " << item->isUsed() << "\n";
	}

	file.close();

}

GameProgress restoreGameProgress(Maze* maze,ItemStorage* itemStorage) {
	fstream file("gameProgress.dat", ios::in);

	//Map x length
	//Map y length
	//Map
	//Mouse Position
	//Barn Position
	//Time
	//ItemName ItemUsed
	//... ...
	int xLength, yLength;
	file >> xLength >> yLength;

	Map map(xLength, yLength);

	int element;
	for (int y = 0; y < yLength; y++) {
		for (int x = 0; x < xLength; x++) {
			file >> element;
			map.setElemetAt(Position(x, y), element);
		}
	}

	maze->setMap(map);

	int mouseX, mouseY, barnX, barnY;
	file >> mouseX >> mouseY >> barnX >> barnY;

	int time;
	file >> time;

	maze->setMousePosition(Position(mouseX, mouseY));
	maze->setBarnPosition(Position(barnX, barnY));

	for (Item* item : itemStorage->itemList) {
		delete item;
	}
	itemStorage->itemList.clear();

	string itemName;
	bool itemUsed;
	while ((file >> itemName >> itemUsed)) {
		Item* item = NULL;
		if (itemName == "ը��") {
			item = new BombItem();
		}
		else if (itemName == "����") {
			item = new TPITem();
		}
		else {
			continue;
		}

		if (itemUsed) {
			item->markUsed();
		}

		itemStorage->itemList.push_back(item);
	}

	GameProgress gameProgress;
	gameProgress.remaingTime = time;
	gameProgress.maze = maze;
	gameProgress.itemStorage = itemStorage;

	return gameProgress;
}

#endif