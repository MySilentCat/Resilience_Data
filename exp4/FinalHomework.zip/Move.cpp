#include"Move.h"
#include"Position.h"

Move::Move(int direction1, int step1) {
	direction = direction1;
	step = step1;
}

int Move::getDirection() {
	if (direction == 1)
		return DIRECION_X;
	if (direction == 2)
		return DIRECION_Y;
}
int Move::getStep() {
	return step;
}

//��������д˴��ƶ������λ��
Position Move::calculateTargetPosition(const Position& currentPosition) {
	if (direction == DIRECION_X) {
		Position newp = currentPosition;
		newp.setX(step + newp.getX());
		return newp;
	}
	else
	{
		Position newp = currentPosition;
		newp.setY(step + newp.getY());
		return newp;
	}
}
