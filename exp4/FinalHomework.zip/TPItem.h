#pragma once
#ifndef TPITEM_H
#define TPITEM_H

#include "Item.h"

class TPITem : public Item {
public:
	TPITem();

	virtual bool action(Maze* maze, Position target, string* errorMessage);
};

#endif