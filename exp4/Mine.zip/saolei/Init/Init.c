
#include "Init.h"

// 初始化后台
void InitBoard(char board[ROWS][COLS], int rows, int cols, char set) {
  int i = 0;
  for (i = 0; i < rows; i++) {
    int j = 0;
    for (j = 0; j < cols; j++) {

      board[i][j] = set;
    }
  }
}

// 布雷
void SetMine(char board[ROWS][COLS], int row, int col) {

  int count = EASY_COUNT;

  while (count) {

    int x = rand() % row + 1;
    int y = rand() % col + 1;
    if (board[x][y] != '1') {
      board[x][y] = '1';
      count--;
    }
  }
}