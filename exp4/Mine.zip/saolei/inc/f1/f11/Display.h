#define ROW 9
#define COL 9

#define ROWS ROW + 2 // 让外面增加一圈，使数组不越界
#define COLS COL + 2
#define EASY_COUNT 10
void DisplayBoard(char board[ROWS][COLS], int row, int col);