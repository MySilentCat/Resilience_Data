#include <stdio.h>
#include <stdlib.h>
#define ROW 9
#define COL 9

#define ROWS ROW + 2 // 让外面增加一圈，使数组不越界
#define COLS COL + 2
#define EASY_COUNT 10

void InitBoard(char board[ROWS][COLS], int rows, int cols, char set);
void SetMine(char board[ROWS][COLS], int row, int col);