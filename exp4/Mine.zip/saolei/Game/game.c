
#include "game.h"
#include "../ShowBoard/Display.h"
int GetMineCount(char Mine[ROWS][COLS], int x, int y) {
  int ret = 0;
  int i = 0;
  for (i = x - 1; i <= x + 1; i++) {
    int j = 0;
    for (j = y - 1; j <= y + 1; j++) {
      ret = ret + Mine[i][j] - '0';
    }
  }
  return ret;
}

// 排雷游戏开始
void FindMine(char Mine[ROWS][COLS], char Show[ROWS][COLS], int row, int col) {
  int x = 0;
  int y = 0;
  int win = 0;
  while (win < row * col - EASY_COUNT) {
    printf("请输入要排查的坐标：>");
    scanf("%d %d", &x, &y);
    if (x >= 1 && x <= row && y >= 1 && y <= col) {
      if (Mine[x][y] == '1') {
        printf("很遗憾，你被炸死了\n");
        DisplayBoard(Mine, ROW, COL);
        break;
      } else {
        int count = GetMineCount(Mine, x, y);
        Show[x][y] = count + '0';
        DisplayBoard(Show, ROW, COL);
        win++;
      }
    } else {
      printf("坐标非法，请重新输入：\n");
    }
  }
  if (win == row * col - EASY_COUNT) {
    printf("恭喜你赢得胜利！\n");
    DisplayBoard(Mine, ROW, COL);
  }
}
