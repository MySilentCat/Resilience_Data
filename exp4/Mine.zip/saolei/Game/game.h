#include <stdio.h>
#include <stdlib.h>
#include <time.h>

#define ROW 9
#define COL 9

#define ROWS ROW + 2 // 让外面增加一圈，使数组不越界
#define COLS COL + 2

#define EASY_COUNT 10
int GetMineCount(char Mine[ROWS][COLS], int x, int y);
void FindMine(char Mine[ROWS][COLS], char Show[ROWS][COLS], int row, int col);