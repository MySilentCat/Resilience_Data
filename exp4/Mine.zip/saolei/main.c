#include "./Game/game.h"
#include "./Init/Init.h"
#include "./Menu/menu.h"
#include "./ShowBoard/Display.h"
void game() {
  char Mine[ROWS][COLS] = {0};      // 创建初始后台数组
  char Show[ROWS][ROWS] = {0};      // 创建初始扫雷数组
  InitBoard(Mine, ROWS, COLS, '0'); // 初始化后台
  InitBoard(Show, ROWS, COLS, '*'); // 初始化扫雷
  SetMine(Mine, ROW, COL);          // 布雷
  DisplayBoard(Mine, ROW, COL);     // 打印棋盘
  DisplayBoard(Show, ROW, COL);     // 打印棋盘
  FindMine(Mine, Show, ROW, COL);   // 排雷游戏开始
}

int main() {
  int input = 0;
  srand((unsigned int)time(NULL)); // 初始化时间戳
  do {
    menu();
    printf("请选择:>");
    scanf("%d", &input);
    switch (input) {
    case 1:
      game();
      break;
    case 0:
      printf("已退出游戏！");
      break;
    default:
      printf("选择错误，请重新选择！\n");
      break;
    }

  } while (input);
  return 0;
}