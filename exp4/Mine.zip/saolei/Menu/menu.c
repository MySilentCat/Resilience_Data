#include "menu.h"
#include <stdio.h>

void menu() {
  printf("**********************************\n");
  printf("*********     1.play     *********\n");
  printf("*********     0.exit     *********\n");
  printf("**********************************\n");
}