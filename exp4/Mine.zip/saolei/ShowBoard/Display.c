#include "Display.h"
#include <stdio.h>

// 打印棋盘
void DisplayBoard(char board[ROWS][COLS], int row, int col) {
  int i = 0;
  printf("            扫雷小游戏      \n");
  printf("       --------------------\n");
  for (i = 0; i <= 9; i++) // 顶部数字顺序
  {

    if (i == 0) {
      printf("      |0 ");
    } else
      printf("%d ", i);
  }

  printf("|");
  printf("\n");

  for (i = 1; i <= row; i++) {
    int j = 0;
    printf("      |");
    printf("%d ", i); // 打印每一行前面的顺序数

    for (j = 1; j <= col; j++) {
      printf("%c ", board[i][j]); // 打印棋盘内
    }
    printf("|");
    printf("\n");
  }
  printf("       --------------------\n");
}