/*
 * ccp_interface.c
 *
 *  Created on: 2015-8-12
 *      Author: Administrator
 */
#include "ccp.h"
#include <string.h>
#include "UI_Fun.h"
//#include "global_variable.h"
#ifndef CCP_INTERFACE_C_
#define CCP_INTERFACE_C_

#define FLASH        ccpFlash
#define FLASH_SIZE   1024*10
#define FLASH_START  &ccpFlash[0]
#define FLASH_LAST   &ccpFlash[FLASH_SIZE-1]

CCP_BYTE ccpFlash[FLASH_SIZE] = {0};

// ==0 - Ram
// !=0 - Flash
CCP_DWORD ccpCalPage = 0;

CAN_Msg Tx_msg_101;

void flashCopy(void);
/*****************************************************************************/
/*CALCULATE new measurements*/
/*****************************************************************************/
void ccpUserBackground(void)
{
}

/*****************************************************************************/
/*SENDING an CRM*DTO when receiving an CRO*/
/*****************************************************************************/
void ccpSend(CCP_BYTEPTR msg)
{
	memcpy(Tx_msg_101.Data,msg,sizeof(Tx_msg_101.Data));
	CAN2_Send(0x50,&Tx_msg_101);
	CAN2_Flush();
}

/*****************************************************************************/
/*CONVERT pointer*/
/*****************************************************************************/
CCP_MTABYTEPTR ccpGetPointer(CCP_BYTE addr_ext, CCP_DWORD addr)
{
	return (CCP_MTABYTEPTR)addr;
}

void ccpFlashClear(CCP_MTABYTEPTR a, CCP_DWORD size)
{

}

CCP_BYTE ccpFlashProgramm(CCP_BYTEPTR data, CCP_MTABYTEPTR a, CCP_BYTE size)
{
	if(size == 0)
	{
		// Simulate Reset
		flashCopy();
		ccp.SessionStatus &= ~SS_CONNECTED; /* DISCONNECT */
	}
	else
	{
//		flashProgramm(data, a, size);
	}
	return CCP_WRITE_OK;
}

CCP_DWORD ccpGetCalPage(void)
{
	return ccpCalPage;
}

void ccpSetCalPage(CCP_DWORD a)
{
//	if (ccpCalPage) 
//	{ // Trick: Backtransform MTA
//		ccpCalPage = flashGetAddress((unsigned char*)a);
//	}
//	else
//	{
//		ccpCalPage = ramGetAddress((unsigned char*)a);
//	}

  #ifdef CCP_TESTMODE
    if (gDebugLevel) {
      printf("Set Calibration Page to %s\n",(ccpCalPage)?"FLASH":"RAM");
    }
  #endif
}

void flashCopy(void)
{
//  unsigned int i;
//  #ifdef CCP_TESTMODE
//    if(gDebugLevel)
//		{
//      printf("Copy Flash to Ram\n");
//    }
//  #endif

//  for(i = 0; i < 0x10000; i++)
//	{
//    if(ram[i])
//		{
//      free(ram[i]);
//      ram[i] = 0;
//    }
//  }
//  for(i = 0; i < 0x10000; i++)
//	{
//    if(flash[i])
//		{
//      memcpy(ramGetPointer(i<<16), flash[i], 0x10000);
//    }
//  }
}

#endif /* CCP_INTERFACE_C_ */
