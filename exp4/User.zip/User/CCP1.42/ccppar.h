/*
 * ccppar1.h
 *
 *  Created on: 2015-8-12
 *      Author: Administrator
 */

#ifndef CCPPAR1_H_
#define CCPPAR1_H_
#define C_ENABLE_CCP
//#define C_MINI_CAN_DRIVER
//#define C_COMP_TASKING_C16X

//#define CCP_TESTMODE /* Turn on screen output via printf */
//#define CCPPRINT printf

#define CCP_INTEL
//#define CCP_CPUTYPE_32BIT
//#define CCP_STANDARD

#define CCP_RAM
#define CCP_ROM     const

#define CCP_BYTE    unsigned char
#define CCP_WORD    unsigned short
#define CCP_DWORD   unsigned long
#define CCP_BYTEPTR unsigned char*
#define CCP_MTABYTEPTR unsigned char*
#define CCP_DAQBYTEPTR unsigned char*

#define CCP_DISABLE_INTERRUPT
#define CCP_ENABLE_INTERRUPT

#define CCP_STATION_ID "CCPtest"
#define CCP_STATION_ADDR 0x1234

#define CCP_DTO_ID 0x101
#define CCP_CRO_ID 0x100

#define CCP_DAQ //ʹ�����ݲɼ�ģʽ
#define CCP_MAX_ODT 7
#define CCP_MAX_DAQ 10

//#define CCP_SEND_QUEUE
#define CCP_SEND_QUEUE_OVERRUN_INDICATION
#define CCP_SEND_QUEUE_SIZE (CCP_MAX_ODT*CCP_MAX_DAQ)

//#define CCP_SEND_QUEUE
//#define CCP_SEND_QUEUE_SIZE 6
#define CCP_SEND_SINGLE

#define CCP_CHECKSUM
#define CCP_CHECKSUM_TYPE CCP_WORD
#define CCP_CHECKSUM_CCITT

#define CCP_SET_SESSION_STATUS
#define CCP_DOUBLE_FLOAT
#define CCP_ODT_ENTRY_SIZE

//#define CCP_DAQ_BASE_ADDR

//#define CCP_BOOTLOADER_DOWNLOAD
//#define CCP_BOOTLOADER
#define CCP_PROGRAM
//#define CCP_CALPAGE
//#define CCP_TESTMODE
//#define CCP_EXTERNAL_STATION_ID
//#define CCP_WRITE_PROTECTION
//#define CCP_WRITE_EEPROM
//#define CCP_READ_EEPROM
#define CCP_SEED_KEY
//#define CCP_TIMESTAMPING



#define CCP_CMD_NOT_IN_INTERRUPT  //ccpCommand(CCP_RX_DATA_PTR);
#endif /* CCPPAR1_H_ */
