#include "UI_Fun.h"
#include "UI_Var.h"
#include "core_cm4.h"
#include "PWM_Example.h"
#include "CAN_Example.h"

uint8_t i = 0;
extern uint8_t pwmflag;

float PLC_Voltage;
float PLC_Temperature;
/* �û�ͷ�ļ����� */
#include "Bits.h"

void PLC_PRG(void)
{
//	PLC_Voltage = AI_Voltage[AI_PWR]; //���ڵײ�ת����ֱ�ӻ�ȡ��Դ��ѹ
//	PLC_Temperature = AI_Voltage[AI_TMP]; //���ڵײ�ת����ֱ�ӻ�ȡMCU�¶�
	
	CAN_Example();
	DO_Val[DO1]  = TRUE;
	DO_Val[DO2]  = TRUE;
	DO_Val[DO3]  = TRUE;
//	PWM_Current[PWM1] = 800;
//	
	
	//	if(pwmflag == 1)
//	{
//		if(i < 90)
//		{
//			PWM_Current[PWMTEST] = i*10;
//			i++;
//		}
//	}
//	else if(pwmflag == 2)
//	{
//		if(i > 0)
//		{
//			i--;
//			PWM_Current[PWMTEST] = i*10;
//		}
//	}

//	if(DI_Val[DI1] == TRUE)	DO_Val[DO1]  = TRUE;
//	else 										DO_Val[DO1]  = FALSE;
//	if(DI_Val[DI2] == TRUE)	DO_Val[DO2]  = TRUE;
//	else 										DO_Val[DO2]  = FALSE;
//	if(DI_Val[DI3] == TRUE)	DO_Val[DO3]  = TRUE;
//	else 										DO_Val[DO3]  = FALSE;
//	if(DI_Val[DI4] == TRUE)	DO_Val[DO4]  = TRUE;
//	else 										DO_Val[DO4]  = FALSE;
//	if(DI_Val[DI5] == TRUE)	DO_Val[DO5]  = TRUE;
//	else 										DO_Val[DO5]  = FALSE;
//	if(DI_Val[DI6] == TRUE)	DO_Val[DO6]  = TRUE;
//	else 										DO_Val[DO6]  = FALSE;
//	if(DI_Val[DI7] == TRUE)	DO_Val[DO7]  = TRUE;
//	else 										DO_Val[DO7]  = FALSE;
//	if(DI_Val[DI8] == TRUE)	DO_Val[DO8]  = TRUE;
//	else 										DO_Val[DO8]  = FALSE;
//	if(DI_Val[DI9] == TRUE)	DO_Val[DO9]  = TRUE;
//	else 										DO_Val[DO9]  = FALSE;
//	if(DI_Val[DI10] == TRUE)DO_Val[DO17] = TRUE;
//	else 										DO_Val[DO17] = FALSE;
//	if(DI_Val[DI11] == TRUE)DO_Val[DO18] = TRUE;
//	else 										DO_Val[DO18] = FALSE;
//	if(DI_Val[DI12] == TRUE)DO_Val[DO19] = TRUE;
//	else 										DO_Val[DO19] = FALSE;
//	if(DI_Val[DI13] == TRUE)DO_Val[DO20] = TRUE;
//	else 										DO_Val[DO20] = FALSE;
//	if(DI_Val[DI14] == TRUE)DO_Val[DO21] = TRUE;
//	else 										DO_Val[DO21] = FALSE;
//	if(DI_Val[DI15] == TRUE)DO_Val[DO22] = TRUE;
//	else 										DO_Val[DO22] = FALSE;
//	if(DI_Val[DI16] == TRUE)DO_Val[DO23] = TRUE;
//	else 										DO_Val[DO23] = FALSE;
//	if(DI_Val[DI17] == TRUE)DO_Val[DO24] = TRUE;
//	else 										DO_Val[DO24] = FALSE;
}
