#ifndef __CAN_EXAMPLE_H_
#define __CAN_EXAMPLE_H_

extern void CAN_Example(void);
extern void CAN_Send_Example(void);
extern void CAN_Rec_Example(void);
#endif
