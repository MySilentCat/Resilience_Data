#ifndef __AI_EXAMPLE_H_
#define __AI_EXAMPLE_H_

void AI_Example(void);

#endif
