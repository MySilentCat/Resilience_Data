#ifndef __DI_EXAMPLE_H_
#define __DI_EXAMPLE_H_

void DI_Example(void);

#endif
