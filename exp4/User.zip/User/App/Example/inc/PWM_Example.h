#ifndef __PWM_EXAMPLE_H_
#define __PWM_EXAMPLE_H_

void PWM_Example(void);

#endif
