//#include "CAN_Example.h"
#include "PWM_UI.h"
#include "DO_UI.h"
#include "AI_UI.h"
#include "PI_UI.h"
/* �����ͷ�ļ����뱻���� */
#include "CAN_UI.h"
#include "UI_Fun.h"


static void CAN_Send_Example(void);
static void CAN_Rec_Example(void);

/* step1: ����CAN_Config_NL.h�ļ�������*/

/* step2: ��CAN1_Para.c��CAN2_Para.c�ļ��н��з��͡����սڵ����� */

/* step3: ��д���CAN����������ֻ��ʾ�� */
uint8_t pwmflag = 0;

CAN_Msg CAN1_TxMsg_0x501, CAN1_TxMsg_0x100, CAN1_TxMsg_0x101;
CAN_Msg CAN2_TxMsg_0x200, CAN2_TxMsg_0x201;
CAN_Msg CAN3_TxMsg_0x182;
CAN_Msg CAN4_TxMsg_0x183;

CAN_Msg CAN1_Rx_msg_110;
CAN_Msg CAN2_Rx_msg_220;

void CAN_Example()
{
	CAN_Send_Example();
	CAN_Rec_Example();
}

void CAN_Send_Example(void)
{
	static uint32_t count = 0;
//	/* ��ʱ���;��� */
	if((count % 10) == 0)
	{
		CAN1_TxMsg_0x501.Data[0] = 0x01;
		CAN1_TxMsg_0x501.Data[1] = 0x00;
		CAN1_TxMsg_0x501.Data[2] = 0x00;
		CAN1_TxMsg_0x501.Data[3] = 0x00;
		CAN1_TxMsg_0x501.Data[4] = 0x00;
		CAN1_TxMsg_0x501.Data[5] = 0x00;
		CAN1_TxMsg_0x501.Data[6] = 0x00;
		CAN1_TxMsg_0x501.Data[7] = 0x00;
	
		CAN1_Send(0, &CAN1_TxMsg_0x501);
		CAN1_Flush();
//		
//		CAN2_Send(0, &CAN2_TxMsg_0x181);
//		CAN2_Flush();

//		CAN3_Send(0, &CAN3_TxMsg_0x182);
//		
//		CAN4_Send(0, &CAN4_TxMsg_0x183);
		
//		Tx_msg_26A.Data[0] = PI_Freq[0]>>8;
//		Tx_msg_26A.Data[1] = PI_Freq[0];
//		Tx_msg_26A.Data[2] = PI_Freq[1]>>8;
//		Tx_msg_26A.Data[3] = PI_Freq[1];
//		Tx_msg_26A.Data[4] = PI_Freq[2]>>8;
//		Tx_msg_26A.Data[5] = PI_Freq[2];
//		Tx_msg_26A.Data[6] = PI_Freq[3]>>8;
//		Tx_msg_26A.Data[7] = PI_Freq[3];

//		Tx_msg_26A.Data[0] = AI_Val_Raw[0]>>8;
//		Tx_msg_26A.Data[1] = AI_Val_Raw[0];
//		Tx_msg_26A.Data[2] = AI_Val_Raw[1]>>8;
//		Tx_msg_26A.Data[3] = AI_Val_Raw[1];
//		Tx_msg_26A.Data[4] = AI_Val_Raw[2]>>8;
//		Tx_msg_26A.Data[5] = AI_Val_Raw[2];
//		Tx_msg_26A.Data[6] = AI_Val_Raw[8]>>8;
//		Tx_msg_26A.Data[7] = AI_Val_Raw[8];

//		Tx_msg_26B.Data[0] = 0x00;
//		Tx_msg_26B.Data[1] = 0x00;
//		Tx_msg_26B.Data[2] = 0x01;
//		Tx_msg_26B.Data[3] = 0x00;
//		Tx_msg_26B.Data[4] = 0x00;
//		Tx_msg_26B.Data[5] = 0x00;
//		Tx_msg_26B.Data[6] = 0x00;
//		Tx_msg_26B.Data[7] = 0x00;
//		
//		Tx_msg_26D.Data[0] = 0x00;
//		Tx_msg_26D.Data[1] = 0x00;
//		Tx_msg_26D.Data[2] = 0x01;
//		Tx_msg_26D.Data[3] = 0x00;
//		Tx_msg_26D.Data[4] = 0x00;
//		Tx_msg_26D.Data[5] = 0x00;
//		Tx_msg_26D.Data[6] = 0x00;
//		Tx_msg_26D.Data[7] = 0x00;
//		
//		Tx_msg_26C.Data[0] = 0x00;
//		Tx_msg_26C.Data[1] = 0x00;
//		Tx_msg_26C.Data[2] = 0x01;
//		Tx_msg_26C.Data[3] = 0x00;
//		Tx_msg_26C.Data[4] = 0x00;
//		Tx_msg_26C.Data[5] = 0x00;
//		Tx_msg_26C.Data[6] = 0x00;
//		Tx_msg_26C.Data[7] = 0x00;
//		CAN3_Send(3, &Tx_msg_26A);
//		CAN3_Send(4, &Tx_msg_26B);
//		CAN3_Send(5, &Tx_msg_26D);
//		CAN3_Send(6, &Tx_msg_26C);
	}
	count++;
}

void CAN_Rec_Example(void)
{
	uint8_t i = 0;
	uint8_t flag1, flag2, flag3, flag4;
	
	flag1 = 0;
	flag2 = 0;
	flag3 = 0;
	flag4 = 0;
	
	CAN1_Recv(2, &CAN1_Rx_msg_110);
	if(CAN1_Rx_msg_110.New_Msg)
	{
		for(i = 0; i < 8; i++)
		{
			CAN1_TxMsg_0x100.Data[i] = CAN1_Rx_msg_110.Data[i];
		}
		CAN1_Send(1, &CAN1_TxMsg_0x100);
		for(i = 0; i < 8; i++)
		{
			if(CAN1_TxMsg_0x100.Data[i] != CAN1_Rx_msg_110.Data[i])
			{
				flag1 = 1;
				DO_Val[DO1]  = TRUE;
			}
		}
		if(flag1 == 0)
			CAN1_Flush();
		
		for(i = 0; i < 8; i++)
		{
			CAN1_TxMsg_0x101.Data[i] = CAN1_Rx_msg_110.Data[i];
		}
		CAN1_Send(2, &CAN1_TxMsg_0x101);
		for(i = 0; i < 8; i++)
		{
			if(CAN1_TxMsg_0x101.Data[i] != CAN1_Rx_msg_110.Data[i])
			{
				flag2 = 1;
				DO_Val[DO2]  = TRUE;
			}
		}
		if(flag2 == 0)
			CAN1_Flush();
	}
	
	CAN2_Recv(2, &CAN2_Rx_msg_220);
	if(CAN2_Rx_msg_220.New_Msg)
	{
		for(i = 0; i < 8; i++)
		{
			CAN2_TxMsg_0x200.Data[i] = CAN2_Rx_msg_220.Data[i];
		}
		CAN2_Send(1, &CAN2_TxMsg_0x200);
		for(i = 0; i < 8; i++)
		{
			if(CAN2_TxMsg_0x200.Data[i] != CAN2_Rx_msg_220.Data[i])
			{
				flag3 = 1;
				DO_Val[DO3]  = TRUE;
			}
		}
		if(flag3 == 0)
			CAN2_Flush();
		
		for(i = 0; i < 8; i++)
		{
			CAN2_TxMsg_0x201.Data[i] = CAN2_Rx_msg_220.Data[i];
		}
		CAN2_Send(2, &CAN2_TxMsg_0x201);
		for(i = 0; i < 8; i++)
		{
			if(CAN2_TxMsg_0x201.Data[i] != CAN2_Rx_msg_220.Data[i])
			{
				flag4 = 1;
				DO_Val[DO4]  = TRUE;
			}
		}
		if(flag4 == 0)
			CAN2_Flush();
	}
}
