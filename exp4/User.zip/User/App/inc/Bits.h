/*-----------------------------------------------------------------------
* Bits.h  -
*
*
*
* History: a.2015.06.16  Create
*-----------------------------------------------------------------------*/
#ifndef _BITS_H_
#define _BITS_H_

	#include "Stdint.h"
	
	typedef volatile struct
	{
  		uint8_t    bit0      : 1;
		uint8_t    bit1      : 1;
  		uint8_t    bit2      : 1;
  		uint8_t    bit3      : 1;
  		uint8_t    bit4      : 1;
  		uint8_t    bit5      : 1;
  		uint8_t    bit6      : 1;
  		uint8_t    bit7      : 1;
	} _byte_bit;

	//***********************************************
	//           �ֽ�������λ����
	//(xΪ8λ�޷������ͣ���Ҫ����CAN�����ֽڵ�λ����)
	//***********************************************
	#define _bit0(x)  ((_byte_bit*)&(x))->bit0
	
	#define _bit1(x)  ((_byte_bit*)&(x))->bit1
	
	#define _bit2(x)  ((_byte_bit*)&(x))->bit2
	
	#define _bit3(x)  ((_byte_bit*)&(x))->bit3
	
	#define _bit4(x)  ((_byte_bit*)&(x))->bit4
	
	#define _bit5(x)  ((_byte_bit*)&(x))->bit5
	
	#define _bit6(x)  ((_byte_bit*)&(x))->bit6
	
	#define _bit7(x)  ((_byte_bit*)&(x))->bit7
	
#endif
