#ifndef _PIN_TYPES_UI_H_
#define _PIN_TYPES_UI_H_
#include "Typedefs.h"
	/*PLC Pin Types*/
	#define  PIN_TYPE_NOT_USED (uint8_t)0x00
	
	#define  PIN_TYPE_DI       (uint8_t)0x01
	
	#define  PIN_TYPE_AI       (uint8_t)0x02
	
	#define  PIN_TYPE_PI       (uint8_t)0x03
  
	#define  PIN_TYPE_DO       (uint8_t)0x04
	
	#define  PIN_TYPE_PWM      (uint8_t)0x05

	#define  PIN_TYPE_CAN      (uint8_t)0x06

	/*PLC Pull Types */
	#define  PULL_NOT_USED		(uint8_t)0x00
	
	#define  PULL_UP        	(uint8_t)0x01
	
	#define  PULL_DOWN      	(uint8_t)0x02
	
	/*AI type*/
	#define  SIGNAL_VOLTAGE   	0x00
	
	#define  SIGNAL_CURRENT   	0x01
	
	#define  SIGNAL_RES       	0x02

	/*PWM feedback*/
	#define FB_NOT_USED 		FALSE 
	
	#define FB_ENABLED  		TRUE

#endif
