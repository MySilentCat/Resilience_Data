#ifndef __CAN_UI_DATATYPES_H_
#define __CAN_UI_DATATYPES_H_
#include "Typedefs.h"
 
typedef struct
{
	uint32_t ID;			/* CAN ID Value(ID_EXT:0~0x1fffffff; ID_STD:0~0x7ff),if you are send 
								a msg to can network,this param is invalidate,you can ignore it*/
	uint8_t  ID_Format; 	/* CAN ID format(CAN_ID_EXT(29-bit) or CAN_ID_STD(11_bit)),if you are 
								send a msg to can network,this param is invalid,you can ignore it*/
	uint8_t  Length;		/* Data Length(0~8)*/
	uint8_t  Data[8]; 		/* Contains the data to be transmitted.Its ranges from 0 to 0xFF. */
	Bool     New_Msg;    	/* if GE 1,it indicates that received new data,if you are send a msg 
								to can network,this param is invalid*/	
	uint16_t OverflowCount;	/* overflow count,if you are send a msg to can network,this param is 
								invalid*/
	uint16_t SeqNum;		/* 0-65535 */
	Bool	 Retrieving_Data;			
}CAN_Msg;

typedef struct 
{
	uint16_t  SeqNum;     	/* 0-65535 */
	uint8_t   Mode;       	/* CAN_MODE_TX or CAN_MODE_RX */
	uint8_t   ID_Format;  	/* CAN ID format(CAN_ID_EXT(29-bit) or CAN_ID_STD(11_bit)) */
	uint8_t   Length;     	/* Data Length(0~8) */
	uint32_t  ID;         	/* CAN ID Value(ID_EXT:0~0x1fffffff; ID_STD:0~0x7ff) */
}CAN_Config;

/** @defgroup ID_Format Value of CAN_Config  
  * @{
  */
#define CAN_ID_STD		((uint8_t)0x00000000)  /*!< Standard Id */
#define CAN_ID_EXT		((uint8_t)0x00000004)  /*!< Extended Id */

/** @defgroup Mode Value of CAN_Config  
  * @{
  */
#define CAN_MODE_TX		((uint8_t)0x00000000)  /*!<Send mode 		*/
#define CAN_MODE_RX		((uint8_t)0x00000001)  /*!<Recieve mode */

/** @defgroup all validate baudrates
  * @{
  */
typedef enum 
{
	BTR_1M,
	BTR_500K,
	BTR_250K,
	BTR_125K,
	BTR_100K,
	BTR_50K,
	BTR_20K,
	BTR_10K,
	BTR_5K,
	BTR_MAX,
}BTR_Val;

#endif
