#ifndef _UI_VAR_H_
#define _UI_VAR_H_

	#include "DI_UI.h"
	#include "AI_UI.h"
	#include "PI_UI.h"
	#include "DO_UI.h"
	#include "PWM_UI.h"
	#include "SPI_UI.h"

	extern uint32_t SystemTick;

#endif
