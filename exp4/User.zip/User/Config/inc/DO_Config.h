/*-----------------------------------------------------------------------------
* DO_Config.h  -
* DO configuration,include:
* 		1. Pin function, the default is PIN_TYPE_NOT_USED
*       2. Pin detection, open or not 
*       3. Corss detcetion, open or not
* Copyright (C) 2017 XCMG Group.
* History: a.2017.07.24  Create
*-----------------------------------------------------------------------------*/

#ifndef _DO_CONFIG_H_
#define _DO_CONFIG_H_

	#include "PinTypes_UI.h"
	//--------------------------------------------
	//First step:Please select the pin function
	//(two types can be selected)
	//--------------------------------------------
	/*
		PIN_TYPE_NOT_USED
		PIN_TYPE_DO
	*/
	#define PIN_DO1_SEL  		PIN_TYPE_DO		//DO1

	#define PIN_DO2_SEL  		PIN_TYPE_DO		//DO2
	
	#define PIN_DO3_SEL  		PIN_TYPE_DO		//DO3
	
	#define PIN_DO4_SEL  		PIN_TYPE_DO		//DO4
	
	#define PIN_DO5_SEL  		PIN_TYPE_DO		//DO5
	
	#define PIN_DO6_SEL  		PIN_TYPE_DO		//DO6

	#define PIN_DO7_SEL 		PIN_TYPE_DO		//DO7
	
	#define PIN_DO8_SEL 		PIN_TYPE_DO		//DO8
	
	#define PIN_DO9_SEL 		PIN_TYPE_DO		//DO9
	
	#define PIN_DO10_SEL 		PIN_TYPE_DO		//DO10
	
	#define PIN_DO11_SEL 		PIN_TYPE_DO		//DO11
	
	#define PIN_DO12_SEL 		PIN_TYPE_DO		//DO12
	
	#define PIN_DO13_SEL 		PIN_TYPE_DO		//DO13
	
	#define PIN_DO14_SEL 		PIN_TYPE_DO		//DO14
	
	#define PIN_DO15_SEL 		PIN_TYPE_DO		//DO15
	
	#define PIN_DO16_SEL 		PIN_TYPE_DO		//DO16
	
	#define PIN_DO17_SEL 		PIN_TYPE_DO		//DO17
	
	#define PIN_DO18_SEL 		PIN_TYPE_DO		//DO18
	
	#define PIN_DO19_SEL 		PIN_TYPE_DO		//DO19
	
	#define PIN_DO20_SEL 		PIN_TYPE_DO		//DO20
	
	#define PIN_DO21_SEL 		PIN_TYPE_DO		//DO21
	
	#define PIN_DO22_SEL 		PIN_TYPE_DO		//DO22
	
	#define PIN_DO23_SEL 		PIN_TYPE_DO		//DO23
	
	#define PIN_DO24_SEL 		PIN_TYPE_DO		//DO24
	
	//--------------------------------------------
	//Second step: open the pin detection or not
	//--------------------------------------------
	/*
		TRUE  ��������·��·���
		FALSE ���رտ�·��·���
	*/
	#define	DO_OPEN_DETECTION	TRUE
	
#endif
