/*-----------------------------------------------------------------------------
* PLC_Config.h  -
* PLC configuration,include:
* 									1. Cycle time, the default cylcle time is 10ms
*               		2. CAN node ID, the default ID is 255
* Copyright (C) 2016 XCMG Group.
* History: a.2016.12.13  Create
*-----------------------------------------------------------------------------*/

#ifndef _PLC_CONFIG_H_
#define _PLC_CONFIG_H_

	//---------------------------------------------------------
	//1.Please config the PLC cycle time of your controller 
	//---------------------------------------------------------
	#define PLC_CYCLE_TIME  	10       //unit : ms
										 //range: 2~500

	//---------------------------------------------------------
	//2.Please config the DOG Reset cycle time of your controller 
	//---------------------------------------------------------
	#define DOG_CYCLE_TIME  	20       //unit : ms
										 //range: >= 2*PLC_CYCLE_TIME,����رտ��Ź�
										 
	//--------------------------------------------------------
	//3.��ʾ����汾��
	//��һ���ֽڴ������汾�ţ������Ʒͼֽ�����޸�
	//�ڶ����ֽڴ����Ӱ汾�ţ���ӳ������޸ļ�¼
	//--------------------------------------------------------
	#define CODE_VERS     		0x0101
	
	//---------------------------------------------------------
	//4.Please config the CAN node id of your controller when you 
	//need to download code via CAN communication interface 
	//---------------------------------------------------------
	#define NODE_ID  			(uint8_t)7   //range: 0~255 
	
#endif
