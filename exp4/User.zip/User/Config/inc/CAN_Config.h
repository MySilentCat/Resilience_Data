/*-----------------------------------------------------------------------------
* CAN_Config.h  -
* CAN interface configuration,include:
* 		1. Pin function, the default is PIN_TYPE_NOT_USED
*       2. Baud rate, the default is BTR_250K
* Copyright (C) 2017 XCMG Group.
* History: a.2017.07.24  Create
*-----------------------------------------------------------------------------*/
#ifndef _CAN_CONFIG_H_
#define _CAN_CONFIG_H_

	#include "PinTypes_UI.h"
	
	//--------------------------------------------
	//Second step:Please set the baud rate
	//--------------------------------------------
	/*
		BTR_1M,
		BTR_500K,
		BTR_250K,
		BTR_125K
	*/
		#define CAN1_BAUD_RATE   		BTR_250K  
		
		#define CAN2_BAUD_RATE   		BTR_250K  
		
		#define CAN3_BAUD_RATE   		BTR_250K  

		#define CAN4_BAUD_RATE   		BTR_250K  
	//-------------------------------------------------------------
	//Third step:Please set send & receive can messages as you want  in the following files.
	//		1.CAN1_Para.c
	//    2.CAN2_Para.c
	//		3.CAN3_Para.c
	//    4.CAN4_Para.c
	//-------------------------------------------------------------
	
#endif
