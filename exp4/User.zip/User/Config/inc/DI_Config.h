/*-----------------------------------------------------------------------------
* DI_Config.h  -
* DI configuration,include:
* 		1. Pin function, the default is PIN_TYPE_NOT_USED
*       2. Pull resistance, the default is PULL_DOWN
* Copyright (C) 2016 XCMG Group.
* History: a.2016.12.13  Create
*-----------------------------------------------------------------------------*/

#ifndef _DI_CONFIG_H_
#define _DI_CONFIG_H_

	#include "PinTypes_UI.h"
	//-----------------------------------------------------
	//First step:Please select the pin function
	//(three types can be selected)
	//Note:DI2��4��6��8 can be used as PI port additionally
	//DI9~17ΪAI�˿ڸ��õ�DI����ʹ����ЩDI��ͬʱ��AI_Config.h�ļ������ó�AI��ѹģʽ
	//-----------------------------------------------------
	/*
		PIN_TYPE_NOT_USED
		PIN_TYPE_DI (ALL)
		PIN_TYPE_PI (DI2��4��6��8)
	*/
	#define PIN_DI1_SEL  		PIN_TYPE_DI			//DI1
	
	#define PIN_DI2_SEL  		PIN_TYPE_PI			//DI2  PI1
	
	#define PIN_DI3_SEL  		PIN_TYPE_DI			//DI3
	
	#define PIN_DI4_SEL  		PIN_TYPE_PI			//DI4  PI2
	
	#define PIN_DI5_SEL  		PIN_TYPE_DI			//DI5
	
	#define PIN_DI6_SEL  		PIN_TYPE_PI			//DI6  PI3
	
	#define PIN_DI7_SEL 		PIN_TYPE_DI			//DI7
	
	#define PIN_DI8_SEL 		PIN_TYPE_PI			//DI8  PI4
	
	#define PIN_DI9_SEL  		PIN_TYPE_DI			//DI9  AI1
	
	#define PIN_DI10_SEL  	PIN_TYPE_DI			//DI10  AI2
	
	#define PIN_DI11_SEL  	PIN_TYPE_DI			//DI11  AI3
	
	#define PIN_DI12_SEL  	PIN_TYPE_DI			//DI12  AI4
	
	#define PIN_DI13_SEL  	PIN_TYPE_DI			//DI13  AI5
	
	#define PIN_DI14_SEL  	PIN_TYPE_DI			//DI14  AI6
	
	#define PIN_DI15_SEL 		PIN_TYPE_DI			//DI15  AI7
	
	#define PIN_DI16_SEL 		PIN_TYPE_DI			//DI16  AI8
	
	#define PIN_DI17_SEL 		PIN_TYPE_DI			//DI17  AI9
	//------------------------------------------------------
	//Second Step:Please select the pull resistance
	//Note:DI1-DI4 is specially designed for ECU Output with
	//     pull-down resistance 
	//------------------------------------------------------
	/*
		PULL_NOT_USED 
		PULL_UP,      
 		PULL_DOWN,    
	*/
	#define	PIN_DI1_PULL_SEL			PULL_DOWN										

	#define	PIN_DI2_PULL_SEL			PULL_DOWN										
	
	#define	PIN_DI3_PULL_SEL			PULL_DOWN								
	
	#define	PIN_DI4_PULL_SEL			PULL_DOWN
	
	#define	PIN_DI5_PULL_SEL			PULL_DOWN										
	
	#define	PIN_DI6_PULL_SEL			PULL_DOWN										
	
	#define	PIN_DI7_PULL_SEL			PULL_DOWN								
	
	#define	PIN_DI8_PULL_SEL			PULL_DOWN
	
#endif
