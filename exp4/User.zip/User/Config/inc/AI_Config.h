/*-----------------------------------------------------------------------------
* DI_AI_Config.h  -
* DI/AI configuration,include:
* 		1. Pin function, the default is PIN_TYPE_NOT_USED
*       2. Analog signal type, the default is SIGNAL_VOLTAGE
* Copyright (C) 2016 XCMG Group.
* History: a.2016.12.14  Create
*-----------------------------------------------------------------------------*/
#ifndef _AI_CONFIG_H_
#define _AI_CONFIG_H_

	#include "PinTypes_UI.h"
	//--------------------------------------------
	//First step:Please select the pin type
	//(three types can be selected)
	//--------------------------------------------
	/*
		PIN_TYPE_NOT_USED
		PIN_TYPE_AI
	*/
	#define PIN_AI1_SEL   PIN_TYPE_AI     //AI1(DI9)
	
	#define PIN_AI2_SEL   PIN_TYPE_AI     //AI2(DI10)
	
	#define PIN_AI3_SEL   PIN_TYPE_AI     //AI3(DI11)
	
	#define PIN_AI4_SEL   PIN_TYPE_AI     //AI4(DI12)
	
	#define PIN_AI5_SEL   PIN_TYPE_AI     //AI5(DI13)
	
	#define PIN_AI6_SEL   PIN_TYPE_AI     //AI6(DI14)
	
	#define PIN_AI7_SEL   PIN_TYPE_AI     //AI7(DI15)
	
	#define PIN_AI8_SEL   PIN_TYPE_AI     //AI8(DI16)
	
	#define PIN_AI9_SEL   PIN_TYPE_AI     //AI9(DI17)
	
	//------------------------------------------------------
	//(if you select pin as PIN_TYPE_AI,go to second step)
	//Second Step:Please select the type of analog signal
	//------------------------------------------------------
	/*
		SIGNAL_VOLTAGE   (ALL)
		SIGNAL_CURRENT   (ALL)
		SIGNAL_RES	     (AI1-AI2)
	*/
	#define AI1_SIGNAL_SEL   SIGNAL_VOLTAGE
	
	#define AI2_SIGNAL_SEL   SIGNAL_VOLTAGE
	
	#define AI3_SIGNAL_SEL   SIGNAL_VOLTAGE
	
	#define AI4_SIGNAL_SEL   SIGNAL_VOLTAGE
	
	#define AI5_SIGNAL_SEL   SIGNAL_VOLTAGE
	
	#define AI6_SIGNAL_SEL   SIGNAL_VOLTAGE
	
	#define AI7_SIGNAL_SEL   SIGNAL_VOLTAGE
	
	#define AI8_SIGNAL_SEL   SIGNAL_VOLTAGE
	
	#define AI9_SIGNAL_SEL   SIGNAL_VOLTAGE
	
#endif
