/*-----------------------------------------------------------------------------
* PWM_Config.h  -
* PWM configuration,include:
* 		1. Pin function, the default is PIN_TYPE_NOT_USED
*		2. PWM Frequency, 50HZ-250HZ
*       3. Pin detection, open or not 
*       4. Corss detcetion, open or not
* Copyright (C) 2017 XCMG Group.
* History: a.2017.07.24  Create
*-----------------------------------------------------------------------------*/

#ifndef _PWM_CONFIG_H_
#define _PWM_CONFIG_H_

	#include "PinTypes_UI.h"
	//--------------------------------------------
	//First step:Please select the pin function
	//(two types can be selected)
	//--------------------------------------------
	/*
		PIN_TYPE_NOT_USED
		PIN_TYPE_PWM
	*/
	#define PIN_PWM1_SEL  			PIN_TYPE_PWM		//PWM1
	
	#define PIN_PWM2_SEL  			PIN_TYPE_PWM		//PWM2
	
	#define PIN_PWM3_SEL  			PIN_TYPE_PWM		//PWM3
	
	#define PIN_PWM4_SEL  			PIN_TYPE_PWM		//PWM4
	
	#define PIN_PWM5_SEL  			PIN_TYPE_PWM		//PWM5

	#define PIN_PWM6_SEL  			PIN_TYPE_PWM		//PWM6
	
	#define PIN_PWM7_SEL  			PIN_TYPE_PWM		//PWM7
	
	#define PIN_PWM8_SEL  			PIN_TYPE_PWM		//PWM8
	
	#define PIN_PWM9_SEL  			PIN_TYPE_PWM		//PWM9
	
	#define PIN_PWM10_SEL  			PIN_TYPE_PWM		//PWM10
	
	#define PIN_PWM11_SEL  			PIN_TYPE_PWM		//PWM11

	#define PIN_PWM12_SEL  			PIN_TYPE_PWM		//PWM12
	
	#define PIN_PWM13_SEL  			PIN_TYPE_PWM		//PWM13
	
	#define PIN_PWM14_SEL  			PIN_TYPE_PWM		//PWM14
	
	#define PIN_PWM15_SEL  			PIN_TYPE_PWM		//PWM15

	#define PIN_PWM16_SEL  			PIN_TYPE_PWM		//PWM16
	
	#define PIN_PWM17_SEL  			PIN_TYPE_PWM		//PWM17
	
	#define PIN_PWM18_SEL  			PIN_TYPE_PWM		//PWM18
	
	//---------------------------------------------------
	//Second step:Please set the pwm frequency
	//Note:	PWM1\PWM17\PWM18 must be set the same value
	//		PWM2\PWM5\PWM6 must be set the same value
	//		PWM3\PWM4\PWM7\PWM8 must be set the same value
	//		PWM9\PWM10\PWM11\PWM12 must be set the same value
	//		PWM13\PWM14\PWM15\PWM16 must be set the same value
	//(unit:HZ)
	//---------------------------------------------------
	/*
		50 - 250
	*/
	#define	PWM1_FREQ					250					//PWM1\PWM17\PWM18

	#define	PWM2_FREQ					250		  		//PWM2\PWM5\PWM6

	#define	PWM3_FREQ					250					//PWM3\PWM4\PWM7\PWM8

	#define	PWM9_FREQ					250					//PWM9\PWM10\PWM11\PWM12

	#define	PWM13_FREQ				250					//PWM13\PWM14\PWM15\PWM16

	//---------------------------------------------------
	//Third step:Please set the load resistance value
	//ע�⣺����ֵ�趨ʱ��������Χ���Ƶ���һ�£�
	//  		�����ʵ�ʵ���С1ŷķ������趨����
	//			������һ��ʼ��һ�ζ�������ڳ��
	//---------------------------------------------------
	#define	PWM1_RES					20					//PWM1

	#define	PWM2_RES					20					//PWM2

	#define	PWM3_RES					20					//PWM3

	#define	PWM4_RES					20					//PWM4

	#define	PWM5_RES					20					//PWM5

	#define	PWM6_RES					20					//PWM6

	#define	PWM7_RES					20					//PWM7

	#define	PWM8_RES					20					//PWM8

	#define	PWM9_RES					20					//PWM9

	#define	PWM10_RES					20					//PWM10

	#define	PWM11_RES					20					//PWM11

	#define	PWM12_RES					20					//PWM12

	#define	PWM13_RES					20					//PWM13

	#define	PWM14_RES					20					//PWM14

	#define	PWM15_RES					20					//PWM15

	#define	PWM16_RES					20					//PWM16

	#define	PWM17_RES					20					//PWM17

	#define	PWM18_RES					20					//PWM18	

  //--------------------------------------------
	//Fourth step: open the pin detection or not
	//--------------------------------------------
	/*
		TRUE  ��������·��·���
		FALSE ���رտ�·��·���
	*/
	#define	PWM_OPEN_DETECTION		TRUE
		
#endif
