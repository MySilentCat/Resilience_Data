#ifndef __CAN_PARA_NL_H_
#define __CAN_PARA_NL_H_
	
	#include "CAN_DataTypes_UI.h"

	extern CAN_Config const CAN1_TX_Config[];
	extern CAN_Config const CAN1_RX_Config[];

	extern CAN_Config const CAN2_TX_Config[];
	extern CAN_Config const CAN2_RX_Config[];
	
	extern CAN_Config const CAN3_TX_Config[];
	extern CAN_Config const CAN3_RX_Config[];
	
	extern CAN_Config const CAN4_TX_Config[];
	extern CAN_Config const CAN4_RX_Config[];

	extern uint16_t const CAN1_TX_Config_Count;
	extern uint16_t const CAN1_RX_Config_Count;

	extern uint16_t const CAN2_TX_Config_Count;
	extern uint16_t const CAN2_RX_Config_Count;
	
	extern uint16_t const CAN3_TX_Config_Count;
	extern uint16_t const CAN3_RX_Config_Count;
	
	extern uint16_t const CAN4_TX_Config_Count;
	extern uint16_t const CAN4_RX_Config_Count;

#endif
