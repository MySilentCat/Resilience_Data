#include "CAN_Para.h"

/* User Config of CAN4_TX */
/*	
NOTE :If you do not need send any CAN ID through CAN4, you also need retain one row at least !!!
	  if you do not do like this, you will get an error message at compile phase.
*/
CAN_Config const CAN4_TX_Config[] = 
{
// SeqNum   ,   Mode        ,   ID_Format ,		Length  ,   ID
	{0x00 	, 	CAN_MODE_TX , 	CAN_ID_STD, 	8 		, 	0x183},
};

uint16_t const CAN4_TX_Config_Count = sizeof(CAN4_TX_Config)/sizeof(CAN_Config);

/* User Config of CAN4_RX */
/*	
NOTE :If you do not need recieve any CAN ID through CAN4, you also need retain one row at least !!!
	  if you do not do like this, you will get an error message at compile phase.
*/
CAN_Config const CAN4_RX_Config[] = 
{
	{0x00 	, 	CAN_MODE_RX , 	CAN_ID_STD, 	8 	    , 	0x482},
//�������������������� 
};

uint16_t const CAN4_RX_Config_Count = sizeof(CAN4_RX_Config)/sizeof(CAN_Config);
