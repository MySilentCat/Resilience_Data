#include "CAN_Para.h"

/* User Config of CAN3_TX */
/*	
NOTE :If you do not need send any CAN ID through CAN3, you also need retain one row at least !!!
	  if you do not do like this, you will get an error message at compile phase.
*/
CAN_Config const CAN3_TX_Config[] = 
{
// SeqNum ,   Mode        ,   ID_Format ,		Length ,  ID
	{0x00 	, 	CAN_MODE_TX , 	CAN_ID_STD, 	8 		 , 	0x182},
	{0x03 	, 	CAN_MODE_TX , 	CAN_ID_EXT, 	8 		 , 	0x1CF26A22},
	{0x04 	, 	CAN_MODE_TX , 	CAN_ID_EXT, 	8 		 , 	0x1CF26B22},
	{0x05 	, 	CAN_MODE_TX , 	CAN_ID_EXT, 	8 		 , 	0x1CF26D22},
	{0x06 	, 	CAN_MODE_TX , 	CAN_ID_EXT, 	8 		 , 	0x1CF26C22},
};

uint16_t const CAN3_TX_Config_Count = sizeof(CAN3_TX_Config)/sizeof(CAN_Config);

/* User Config of CAN3_RX */
/*	
NOTE :If you do not need recieve any CAN ID through CAN3, you also need retain one row at least !!!
	  if you do not do like this, you will get an error message at compile phase.
*/
CAN_Config const CAN3_RX_Config[] = 
{
//SeqNum, Mode        , ID_Format ,Length,ID
	{0x00 , CAN_MODE_RX , CAN_ID_STD, 8    , 0x382}, 
	{0x04	,	CAN_MODE_RX	,	CAN_ID_EXT,	8	   , 0x1CF20A21},//0x20A=0x0CF00300
	{0x05	,	CAN_MODE_RX	,	CAN_ID_EXT,	8	   , 0x1CF20B21},//0x20B=0x0CF00400
	{0x06	,	CAN_MODE_RX	,	CAN_ID_EXT,	8	   , 0x1CF20C21},//0x20C=0x18FEEE00
	{0x07	,	CAN_MODE_RX	,	CAN_ID_EXT,	8	   , 0x1CF20D21},//0x20D=0x18FEEF00
	{0x08	,	CAN_MODE_RX	,	CAN_ID_EXT,	8	   , 0x1CF20E21},//0x20E=0x18FEF600
	{0x09	,	CAN_MODE_RX	,	CAN_ID_EXT,	8	   , 0x1CF21A21},//0x21A=0x18FECA00
	{0x0A	,	CAN_MODE_RX	,	CAN_ID_EXT,	8	   , 0x1CF21B21},//0x21B=0x18ECFF00
	{0x0B	,	CAN_MODE_RX	,	CAN_ID_EXT,	8	   , 0x1CF21C21}, //0x21C=0x18EBFF00

	{0x0C	,	CAN_MODE_RX	,	CAN_ID_EXT,	8	   , 0x1CF21D21},
	{0x0D	,	CAN_MODE_RX	,	CAN_ID_EXT,	8	   , 0x1CF22A21},
	{0x0E	,	CAN_MODE_RX	,	CAN_ID_EXT,	8	   , 0x1CF23A21},
	{0x0F	,	CAN_MODE_RX	,	CAN_ID_EXT,	8	   , 0x1CF24A21},
	{0x10	,	CAN_MODE_RX	,	CAN_ID_EXT,	8	   , 0x1CF24B21},
	{0x11	,	CAN_MODE_RX	,	CAN_ID_EXT,	8	   , 0x1CF24C21},
	{0x12	,	CAN_MODE_RX	,	CAN_ID_EXT,	8  	 , 0x1CF24D21},
	{0x13	,	CAN_MODE_RX	,	CAN_ID_EXT,	8  	 , 0x1CF25B21},
	{0x14	,	CAN_MODE_RX	,	CAN_ID_EXT,	8	   , 0x1CF24F21},
	{0x15	,	CAN_MODE_RX	,	CAN_ID_EXT,	8	   , 0x1CF28E21}
};

uint16_t const CAN3_RX_Config_Count = sizeof(CAN3_RX_Config)/sizeof(CAN_Config);
