#include "CAN_Para.h"

/* User Config of CAN1_TX */
/*	
NOTE :If you do not need send any CAN ID through CANA1, you also need retain one row at least !!!
	  if you do not do like this, you will get an error message at compile phase.
*/
CAN_Config const CAN1_TX_Config[] = 
{
// SeqNum   ,   Mode        ,   ID_Format ,		Length  ,   ID
	{0x00 	, 	CAN_MODE_TX , 	CAN_ID_STD, 	8 		, 	0x501},
	{0x01 	, 	CAN_MODE_TX , 	CAN_ID_STD, 	8 		, 	0x100},
	{0x02 	, 	CAN_MODE_TX , 	CAN_ID_STD, 	8 		, 	0x101},
};

uint16_t const CAN1_TX_Config_Count  = sizeof(CAN1_TX_Config)/sizeof(CAN_Config);

/* User Config of CAN1_RX */
/*	
NOTE :If you do not need recieve any CAN ID through CANA1, you also need retain one row at least !!!
	  if you do not do like this, you will get an error message at compile phase.
*/
CAN_Config const CAN1_RX_Config[] = 
{
// 	SeqNum  ,   Mode        ,   ID_Format ,		Length  ,   ID
	{0x00 	, 	CAN_MODE_RX , 	CAN_ID_STD,		8 		, 	0x611},   //ϵͳ�ã���ɾ
	{0x01 	, 	CAN_MODE_RX , 	CAN_ID_STD, 	8 		, 	0x682},   //ϵͳ�ã���ɾ
	{0x02 	, 	CAN_MODE_RX , 	CAN_ID_STD, 	8 		, 	0x110},   //
//��������������������
};

uint16_t const CAN1_RX_Config_Count  = sizeof(CAN1_RX_Config)/sizeof(CAN_Config);
