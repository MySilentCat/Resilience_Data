#ifndef __TYPEDEFS_H_
#define __TYPEDEFS_H_
	
	#include <stdint.h>
	
	typedef enum{
		FALSE = (uint8_t)0, 
		TRUE  = (uint8_t)1
	}Bool;

#endif
