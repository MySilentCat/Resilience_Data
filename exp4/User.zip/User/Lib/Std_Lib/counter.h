/*-----------------------------------------------------------------------
* Counter.h  -
*
*
*
* Copyright (C) 2014 XCMG Group.
*
*-----------------------------------------------------------------------*/
#ifndef _COUNTER_H_
#define _COUNTER_H_
	
	#include "Typedefs.h"
	
	/*
  	Counter Down.
  
  	CV is decremented by 1 if CD has a rising edge.
  	Q is TRUE, if CV reached 0.
	*/
	typedef struct {
		/* input */
  		Bool CD;    /* Count Down on rising edge */
  		Bool LOAD;  /* Load Start Value */
  		uint32_t PV;    /* Start Value */
  		
  		/* output */
  		Bool Q;     /* Counter reached 0 */
  		uint32_t CV;    /* Current Counter Value */
  		
  		/* internal variables */
  		Bool M;     /* Variable for CD Edge Detection */
	} CTD;

	/*
  	Counter Up.
  
  	CV is incremented by 1 if CU has a rising edge.
  	Q is TRUE, if CV is reached PV.
	*/
	typedef struct {
		/* input */
  		Bool CU;     /* Count Up */
  		Bool RESET;  /* Reset Counter to 0 */
  		
  		/* output */
  		uint32_t PV;     /* Counter Limit */
  		Bool Q;      /* Counter reached the Limit  */
  		uint32_t CV;     /* Current Counter Value */
  		
  		/* internal variables */
  		Bool M;      /* Variable for CD Edge Detection */
	} CTU;

	/*
  	Counter Up Down
  
  	CV is decremented by 1 if CD has a rising edge.
  	CV is incremented by 1 if CU has a rising edge.
  	QV is TRUE, if counter is 0.
  	QU is TRUE, if counter is PV.
	*/
	typedef struct {
		/* input */
  		Bool CU;    /* Count Up */
  		Bool CD;    /* Count Down */
  		Bool RESET; /* Reset Counter to Null */
  		Bool LOAD;  /* Load Start Value */
  		uint32_t PV;    /* Start Value / Counter Limit */
  		
  		/* output */
  		Bool QU;    /* Counter reached Limit */
  		Bool QD;    /* Counter reached Null */
  		uint32_t CV;    /* Current Counter Value */
  		
  		/* internal variables */
  		Bool MU;    /* Variable for CU Edge Detection */
  		Bool MD;    /* Variable for CD Edge Detection */
	} CTUD;


void CTd(CTD *pCTD, Bool CD, Bool LOAD, uint32_t PV);
void CTu(CTU *pCTU, Bool CU, Bool RESET, uint32_t PV);
void CTud(CTUD *pCTUD, Bool CU, Bool CD, Bool RESET, Bool LOAD, uint32_t PV);

#endif /* _COUNTER_H_ */
