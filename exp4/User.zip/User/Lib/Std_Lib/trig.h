/*-----------------------------------------------------------------------
* Trig.h  -
*
*
*
* Copyright (C) 2014 XCMG Group.
*
*-----------------------------------------------------------------------*/
#ifndef _TRIG_H_
#define _TRIG_H_
	
	#include "Typedefs.h"
	/*
	Falling edge detection.
	
	each time the function is called up, 
	Q will return FALSE until CLK has a rising followed by a falling edge
	*/
	typedef struct {
  		/* input */
  		Bool CLK;
  		
  		/* output */
  		Bool Q;
  		
  		/* internnal variable */
  		Bool M;   
	} F_TRIG;


	/*
	Rising edge detection
	
	each time the function is called up, 
	Q will return FALSE until CLK has falling edge followed by an rising edge.
	*/
	typedef struct {
		/* input */
  		Bool CLK;
  		
  		/* output */
  		Bool Q;
  		
  		/* internnal variable */
  		Bool M;   
	} R_TRIG;


	void F_Trig(F_TRIG *pFTrig, Bool CLK);
	void R_Trig(R_TRIG *pRTrig, Bool CLK);

#endif /* _TRIG_H_ */
