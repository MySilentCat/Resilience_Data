/*-----------------------------------------------------------------------
* Timer.h  -
* History: a.2015.06.18  Create
*-----------------------------------------------------------------------*/
#ifndef _TIMER_H_
#define _TIMER_H_

#include "Typedefs.h"
/*
Timer Pulse.
If IN is FALSE, Q is FALSE and ET is 0.
As soon as IN becomes TRUE, Q becomes TRUE, the time will begin to be 
counted in ms in ET until its value is equal to PT. It will then remain 
constant.And Q returns False
*/
typedef struct 
{
	/* input */
	Bool IN;  /* starts timer with falling edge, resets timer with rising edge */
	uint32_t PT;  /* time to pass, before Q is set(unit:ms) */

	/* output */
	Bool Q;   /* As soon as IN becomes TRUE, Q becomes TRUE */
	uint32_t ET;  /* The current time,increased by one per ms */

	/* internal variable */
	uint32_t StartTime;  
}TP;

/*
Timer on delay.
Q is TRUE, PT milliseconds after IN had a rising edge.
*/
typedef struct
{
	/* input */
	Bool IN;  /* starts timer with rising edge, resets timer with falling edge */
	uint32_t PT;  /* time to pass, before Q is set */

	/* output */
	Bool Q;   /* is TRUE, PT seconds after IN had a rising edge */
	uint32_t ET;  /* elapsed time */

	/* internal variable */
	uint32_t M;   
	uint32_t StartTime;  
}TON;

/*
Timer off delay.
Q is FALSE, PT milliseconds after IN had a falling edge.
*/
typedef struct
{
	/* input */
	Bool IN;  /* starts timer with falling edge, resets timer with rising edge */
	uint32_t PT;  /* time to pass, before Q is set */

	/* output */
	Bool Q;   /* is FALSE, PT seconds after IN had a falling edge */
	uint32_t ET;  /* elapsed time */

	/* internal variable */
	uint32_t M;   
	uint32_t StartTime;  
} TOF;

void Tp(TP *pTP, Bool IN, uint32_t PT);
void Ton(TON *pTON, Bool IN, uint32_t PT);
void Tof(TOF *pTOF, Bool IN, uint32_t PT);

#endif
